from django.conf.urls.defaults import patterns, include, url

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
import os
admin.autodiscover()

context = os.path.basename(os.path.dirname(os.path.realpath(__file__)))
urlpatterns = patterns('',
    url(r'accounts/register', '%s.views.feedrec'%context),
    url(r'feedrec/','%s.views.feedrec'%context),
    url(r'get_rec/','%s.views.get_rec'%context),
    url(r'unfollow/','%s.views.unfollow'%context),
    url(r'follow/','%s.views.follow'%context),
    url(r'train/','%s.views.train'%context),
    url(r'home/comments','%s.views.home_comments'%context),
    url(r'home/more','%s.views.home_more'%context),
    url(r'home/','%s.views.home'%context),
    url(r'userrec/','%s.views.userrec'%context),
    url(r'profile/users','%s.views.profile_users'%context),
    url(r'profile/ratings','%s.views.profile_ratings'%context),
    url(r'profile/comments','%s.views.profile_comments'%context),
    url(r'profile/','%s.views.profile'%context),
    url(r'rate/','%s.views.rate'%context),
    url(r'reclist','%s.views.reclist'%context),
    url(r'search/','%s.views.search'%context),
    url(r'user_popover/','%s.views.user_popover'%context),
    url(r'detail/(?P<pk>\d+)/','%s.views.detail'%context),
    # Examples:
    # url(r'^$', 'web.views.home', name='home'),
    # url(r'^web/', include('web.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
)
